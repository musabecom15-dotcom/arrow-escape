// Draws the app icons as PNG files using only Node built-ins (no image libraries).
// Run with:  node tools/make-icons.js     -> writes into ./icons/

import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = join(root, 'icons');
mkdirSync(outDir, { recursive: true });

// ---- minimal PNG encoder ----
const CRC = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function encodePNG(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 4 + 1)] = 0; rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4); }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// ---- tiny vector helpers (coordinates in 0..1 space) ----
const hex = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
function inRoundRect(x, y, x0, y0, x1, y1, r) {
  if (x < x0 || x > x1 || y < y0 || y > y1) return false;
  const cx = Math.min(Math.max(x, x0 + r), x1 - r), cy = Math.min(Math.max(y, y0 + r), y1 - r);
  return (x - cx) ** 2 + (y - cy) ** 2 <= r * r;
}
function inPoly(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
// Arrow pointing up inside unit square
const ARROW = [[0.5, 0.14], [0.86, 0.5], [0.64, 0.5], [0.64, 0.86], [0.36, 0.86], [0.36, 0.5], [0.14, 0.5]];
function rotPt(x, y, rot) { // rotate point around 0.5,0.5 by rot*90deg
  for (let i = 0; i < rot; i++) { const nx = 1 - y; y = x; x = nx; }
  return [x, y];
}

const TILES = [
  { x: 0, y: 0, c1: '#6b93ff', c2: '#3f6cf2', rot: 0 }, // up
  { x: 1, y: 0, c1: '#ffa155', c2: '#ff6f2c', rot: 1 }, // right
  { x: 0, y: 1, c1: '#b57cff', c2: '#8a4cf0', rot: 3 }, // left
  { x: 1, y: 1, c1: '#33d6b6', c2: '#10a98d', rot: 2 }, // down
];

/** Sample colour at (x,y) in 0..1. Returns [r,g,b,a] (0..255). */
function sample(x, y, opts) {
  const { rounded, content } = opts; // content = size of logo area (fraction)
  // background
  let bg = null;
  const inside = rounded ? inRoundRect(x, y, 0, 0, 1, 1, 0.22) : true;
  if (inside) {
    const t = (x + y) / 2;
    bg = mix(hex('#24184f'), hex('#5a33c9'), Math.min(1, t * 1.1));
    const glow = Math.max(0, 1 - Math.hypot(x - 0.3, y - 0.25) / 0.7);
    bg = mix(bg, hex('#9b7bff'), glow * 0.35);
  }
  // logo: 2x2 tiles inside a centred square of size `content`
  const o = (1 - content) / 2;
  const lx = (x - o) / content, ly = (y - o) / content;
  if (lx >= 0 && lx <= 1 && ly >= 0 && ly <= 1) {
    const gap = 0.08, size = (1 - gap) / 2;
    for (const t of TILES) {
      const x0 = t.x * (size + gap), y0 = t.y * (size + gap);
      if (inRoundRect(lx, ly, x0, y0, x0 + size, y0 + size, size * 0.28)) {
        const u = (lx - x0) / size, v = (ly - y0) / size;
        const [ax, ay] = rotPt(u, v, (4 - t.rot) % 4);
        // inset arrow a bit
        const ix = 0.5 + (ax - 0.5) / 0.78, iy = 0.5 + (ay - 0.5) / 0.78;
        if (inPoly(ix, iy, ARROW)) return [255, 255, 255, 255];
        const col = mix(hex(t.c1), hex(t.c2), (u + v) / 2);
        return [...col, 255];
      }
    }
    // soft shadow under tiles
  }
  return bg ? [...bg, 255] : [0, 0, 0, 0];
}

function render(size, opts, ss = 4) {
  const buf = Buffer.alloc(size * size * 4);
  for (let py = 0; py < size; py++) {
    for (let px = 0; px < size; px++) {
      let r = 0, g = 0, b = 0, a = 0;
      for (let sy = 0; sy < ss; sy++) for (let sx = 0; sx < ss; sx++) {
        const c = sample((px + (sx + 0.5) / ss) / size, (py + (sy + 0.5) / ss) / size, opts);
        r += c[0] * c[3]; g += c[1] * c[3]; b += c[2] * c[3]; a += c[3];
      }
      const i = (py * size + px) * 4;
      if (a > 0) { buf[i] = Math.round(r / a); buf[i + 1] = Math.round(g / a); buf[i + 2] = Math.round(b / a); }
      buf[i + 3] = Math.round(a / (ss * ss));
    }
  }
  return encodePNG(size, size, buf);
}

const jobs = [
  ['icon-192.png', 192, { rounded: true, content: 0.62 }],
  ['icon-512.png', 512, { rounded: true, content: 0.62 }],
  ['icon-maskable-512.png', 512, { rounded: false, content: 0.5 }], // logo inside the 80% safe zone
  ['apple-touch-icon.png', 180, { rounded: false, content: 0.6 }], // iOS rounds corners itself; must be opaque
  ['favicon-32.png', 32, { rounded: true, content: 0.72 }],
];
for (const [name, size, opts] of jobs) {
  writeFileSync(join(outDir, name), render(size, opts));
  console.log(`wrote icons/${name} (${size}x${size})`);
}
