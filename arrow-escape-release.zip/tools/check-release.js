// Release audit: checks that every file referenced by index.html, the manifest,
// the service worker and JS imports exists, that all paths are relative, that
// the service worker caches every shipped file, and that nothing loads from the internet.
// Run with:  node tools/check-release.js

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, relative, normalize } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const problems = [];
const read = (p) => readFileSync(join(root, p), 'utf8');
const exists = (p) => existsSync(join(root, p));

// 1. index.html references
const html = read('index.html');
const htmlRefs = [...html.matchAll(/(?:href|src)="([^"]+)"/g)].map((m) => m[1]);
for (const r of htmlRefs) {
  if (/^https?:|^\/\//.test(r)) problems.push(`index.html loads external URL: ${r}`);
  else if (r.startsWith('/')) problems.push(`index.html uses absolute path (breaks on GitHub Pages sub-folders): ${r}`);
  else if (!exists(r)) problems.push(`index.html references missing file: ${r}`);
}

// 2. manifest
const man = JSON.parse(read('manifest.webmanifest'));
for (const k of ['start_url', 'scope']) if (!man[k] || man[k].startsWith('/')) problems.push(`manifest ${k} should be relative: ${man[k]}`);
for (const ic of man.icons) {
  if (ic.src.startsWith('/') || /^https?:/.test(ic.src)) problems.push(`manifest icon not relative: ${ic.src}`);
  else if (!exists(ic.src)) problems.push(`manifest icon missing: ${ic.src}`);
}
if (!man.icons.some((i) => i.purpose === 'maskable')) problems.push('manifest has no maskable icon');
for (const s of ['192x192', '512x512']) if (!man.icons.some((i) => i.sizes === s)) problems.push(`manifest missing ${s} icon`);

// 3. service worker precache list
const sw = read('sw.js');
const pre = [...sw.matchAll(/'(\.\/[^']+)'/g)].map((m) => m[1]).filter((p) => p !== './');
for (const p of pre) if (!exists(p)) problems.push(`sw.js precaches missing file: ${p}`);
const shipped = [];
const walk = (dir) => {
  for (const f of readdirSync(join(root, dir))) {
    const rel = dir ? `${dir}/${f}` : f;
    if (statSync(join(root, rel)).isDirectory()) { if (!['tests', 'tools', 'docs', 'node_modules', '.git'].includes(f)) walk(rel); }
    else shipped.push(rel);
  }
};
walk('');
const runtime = shipped.filter((f) => /\.(html|css|js|png|webmanifest)$/.test(f) && f !== 'sw.js' && !f.startsWith('package'));
for (const f of runtime) if (!pre.includes(`./${f}`)) problems.push(`sw.js does not cache shipped file: ./${f}`);

// 4. JS imports resolve, no external URLs in code
const jsFiles = shipped.filter((f) => f.endsWith('.js') || f.endsWith('.css'));
for (const f of jsFiles) {
  const src = read(f);
  for (const m of src.matchAll(/(?:import|from)\s*['"]([^'"]+)['"]/g)) {
    const target = normalize(join(dirname(f), m[1]));
    if (!m[1].startsWith('.')) problems.push(`${f} imports non-relative module: ${m[1]}`);
    else if (!exists(target)) problems.push(`${f} imports missing file: ${m[1]}`);
  }
  if (/https?:\/\/(?!www\.w3\.org)/.test(src.replace(/\/\/.*$/gm, ''))) problems.push(`${f} contains an external URL`);
  if (/url\(\s*['"]?\//.test(src)) problems.push(`${f} has absolute url()`);
}

// 5. required project files
for (const f of ['index.html', 'manifest.webmanifest', 'sw.js', '.nojekyll', 'LICENSE', 'README.md', 'docs/GUIDE.md', 'tests/run-tests.js']) {
  if (!exists(f)) problems.push(`required file missing: ${f}`);
}
if (!/register\('\.\/sw\.js'/.test(read('js/pwa.js'))) problems.push('service worker is not registered with a relative path');

console.log(`Checked ${htmlRefs.length} index.html refs, ${man.icons.length} manifest icons, ${pre.length} cached files, ${jsFiles.length} code files.`);
if (problems.length) { console.log('PROBLEMS:'); problems.forEach((p) => console.log('  - ' + p)); process.exit(1); }
console.log('Release audit passed: all references exist, all paths relative, no external requests, SW caches every shipped file.');
