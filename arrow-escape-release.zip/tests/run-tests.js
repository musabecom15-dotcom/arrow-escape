// Automated tests. Run from the project folder with:   node tests/run-tests.js
// No installs needed (uses only Node's built-in features). Node 18+ recommended.

import { LEVELS } from '../js/data/levels.js';
import { createBoard, findBlocker, canEscape, removeArrow, restoreArrow, freeArrows, distanceToEdge } from '../js/core/board.js';
import { solve, verifySolution } from '../js/core/solver.js';
import { generateLevel } from '../js/core/generator.js';
import { levelParams, LEVEL_COUNT, dailyParams, dateKey, CHAPTERS } from '../js/core/progression.js';
import { GameSession } from '../js/core/game.js';
import { mulberry32, hashString } from '../js/core/rng.js';
import { TUTORIALS } from '../js/data/tutorials.js';

let passed = 0, failed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  \u2714 ${name}`); }
  catch (e) { failed++; console.log(`  \u2718 ${name}\n      ${e.message}`); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (a !== b) throw new Error(`${msg || 'expected equal'}: got ${JSON.stringify(a)}, expected ${JSON.stringify(b)}`); }

// Hand-made board used by rule tests:
//  row0:  .  D  .        A(0,1) points Down  -> blocked by B
//  row1:  .  R  .        B(1,1) points Right -> free
//  row2:  U  .  L        C(2,0) points Up (free), D(2,2) points Left -> blocked by C
const tiny = { rows: 3, cols: 3, arrows: [[0, 1, 2], [1, 1, 1], [2, 0, 0], [2, 2, 3]] };

console.log('\nRNG');
test('same seed gives same sequence', () => {
  const a = mulberry32(42), b = mulberry32(42);
  for (let i = 0; i < 100; i++) eq(a(), b(), 'sequence differs');
});
test('different seeds give different sequences', () => {
  assert(mulberry32(1)() !== mulberry32(2)(), 'seeds 1 and 2 matched');
});
test('hashString is stable', () => {
  eq(hashString('abc'), hashString('abc'));
  assert(hashString('2026-11-13') !== hashString('2026-11-14'), 'adjacent dates hash equal');
});

console.log('\nMove rules');
test('arrow with clear path can escape', () => {
  const b = createBoard(tiny);
  eq(findBlocker(b, 1), -1); assert(canEscape(b, 1)); assert(canEscape(b, 2));
});
test('arrow with another arrow in its path is blocked, blocker reported', () => {
  const b = createBoard(tiny);
  eq(findBlocker(b, 0), 1, 'A should be blocked by B');
  eq(findBlocker(b, 3), 2, 'D should be blocked by C');
});
test('removing a blocker frees the blocked arrow', () => {
  const b = createBoard(tiny);
  removeArrow(b, 1);
  assert(canEscape(b, 0), 'A should be free after B leaves');
});
test('freeArrows lists exactly the movable arrows', () => {
  eq(JSON.stringify(freeArrows(createBoard(tiny))), JSON.stringify([1, 2]));
});
test('distanceToEdge is correct', () => {
  const b = createBoard(tiny);
  eq(distanceToEdge(b, 0), 3); eq(distanceToEdge(b, 1), 2); eq(distanceToEdge(b, 2), 3); eq(distanceToEdge(b, 3), 3);
});
test('restoreArrow puts an arrow back', () => {
  const b = createBoard(tiny);
  removeArrow(b, 1); restoreArrow(b, 1);
  eq(b.alive, 4); eq(findBlocker(b, 0), 1);
});
test('invalid level data is rejected (overlap / out of bounds)', () => {
  let threw = false;
  try { createBoard({ rows: 2, cols: 2, arrows: [[0, 0, 0], [0, 0, 1]] }); } catch { threw = true; }
  assert(threw, 'overlap not rejected');
  threw = false;
  try { createBoard({ rows: 2, cols: 2, arrows: [[5, 0, 0]] }); } catch { threw = true; }
  assert(threw, 'out of bounds not rejected');
});

console.log('\nSolver');
test('solver solves tiny board and its order is valid', () => {
  const r = solve(tiny);
  assert(r.solvable); assert(verifySolution(tiny, r.order));
});
test('solver detects an impossible board (two arrows facing each other)', () => {
  const dead = { rows: 1, cols: 3, arrows: [[0, 0, 1], [0, 2, 3]] };
  assert(!solve(dead).solvable, 'deadlock reported solvable');
});
test('verifySolution rejects an order containing a blocked move', () => {
  assert(!verifySolution(tiny, [0, 1, 2, 3]));
});

console.log('\nGame session (lives, undo, hints, stars)');
test('blocked tap costs a life and does not remove the arrow', () => {
  const g = new GameSession(tiny);
  const r = g.tap(0);
  eq(r.type, 'blocked'); eq(r.blocker, 1); eq(g.lives, 2); eq(g.remaining, 4);
});
test('three blocked taps = game over, further taps ignored', () => {
  const g = new GameSession(tiny);
  g.tap(0); g.tap(0); const r = g.tap(0);
  assert(r.lost); eq(g.status, 'lost'); eq(g.tap(1).type, 'ignored');
});
test('undo restores last successful move, keeps lives spent', () => {
  const g = new GameSession(tiny);
  g.tap(1); g.tap(3); // 3 is blocked by C -> lose a life
  eq(g.lives, 2);
  eq(g.undo(), 1); eq(g.remaining, 4); eq(g.lives, 2, 'undo must not refund lives');
  eq(findBlocker(g.board, 0), 1, 'restored arrow blocks again');
  eq(g.undo(), -1, 'nothing left to undo');
});
test('undo order is last-in-first-out', () => {
  const g = new GameSession(tiny);
  g.tap(1); g.tap(2);
  eq(g.undo(), 2); eq(g.undo(), 1);
});
test('hint always returns a currently valid move', () => {
  const g = new GameSession(LEVELS[40]);
  while (g.status === 'playing') {
    const h = g.hint();
    assert(h >= 0, 'no hint'); assert(canEscape(g.board, h), 'hint is not valid');
    g.tap(h);
  }
  eq(g.status, 'won');
});
test('stars: perfect=3, one mistake=2, hint caps at 2, two mistakes=1', () => {
  const play = (mistakes, hint) => {
    const g = new GameSession(tiny);
    for (let i = 0; i < mistakes; i++) g.tap(0);
    if (hint) g.hint();
    for (const id of solve(tiny).order) g.tap(id);
    return g.stars();
  };
  eq(play(0, false), 3); eq(play(1, false), 2); eq(play(0, true), 2); eq(play(2, false), 1);
});
test('restart (reset) gives a fresh board and full lives', () => {
  const g = new GameSession(tiny);
  g.tap(0); g.tap(1); g.reset();
  eq(g.lives, 3); eq(g.remaining, 4); eq(g.history.length, 0); eq(g.status, 'playing');
});

console.log('\nGenerator');
test('generator is deterministic for the same seed', () => {
  const p = levelParams(57);
  eq(JSON.stringify(generateLevel(p)), JSON.stringify(generateLevel(p)));
});
test('different seeds produce different boards', () => {
  const p = levelParams(57);
  assert(JSON.stringify(generateLevel(p).arrows) !== JSON.stringify(generateLevel({ ...p, seed: p.seed + 1 }).arrows));
});
test('500 random generator runs are all solvable (reverse construction)', () => {
  for (let s = 1; s <= 500; s++) {
    const lvl = generateLevel({ rows: 3 + (s % 7), cols: 3 + (s % 5), count: 40, bias: (s % 10) / 10, targetLayers: 6, seed: s, attempts: 2 });
    assert(solve(lvl).solvable, `seed ${s} unsolvable`);
  }
});
test('daily challenge is deterministic per date and differs between dates', () => {
  const a = generateLevel(dailyParams('2026-11-13'));
  const b = generateLevel(dailyParams('2026-11-13'));
  const c = generateLevel(dailyParams('2026-11-14'));
  eq(JSON.stringify(a), JSON.stringify(b));
  assert(JSON.stringify(a.arrows) !== JSON.stringify(c.arrows));
  assert(solve(a).solvable && solve(c).solvable);
  eq(dateKey(new Date(2026, 0, 5)), '2026-01-05');
});

console.log('\nAll 100 stored levels');
test(`there are exactly ${LEVEL_COUNT} levels, numbered 1..${LEVEL_COUNT}`, () => {
  eq(LEVELS.length, LEVEL_COUNT);
  LEVELS.forEach((l, i) => eq(l.n, i + 1));
});
test('every level loads (valid cells, no overlaps) and is solvable', () => {
  for (const l of LEVELS) {
    const r = solve(l);
    assert(r.solvable, `level ${l.n} NOT solvable`);
    assert(verifySolution(l, r.order), `level ${l.n} solution failed replay`);
    assert(r.initiallyFree >= 1, `level ${l.n} has no starting move`);
  }
});
test('every level can be won through GameSession with zero mistakes', () => {
  for (const l of LEVELS) {
    const g = new GameSession(l);
    for (const id of solve(l).order) eq(g.tap(id).type, 'escaped', `level ${l.n}`);
    eq(g.status, 'won'); eq(g.stars(), 3);
  }
});
test('stored levels exactly match regeneration from their fixed seeds', () => {
  for (const l of LEVELS) {
    const g = generateLevel(levelParams(l.n));
    eq(g.seed, l.seed, `seed L${l.n}`);
    eq(JSON.stringify(g.arrows), JSON.stringify(l.arrows), `arrows L${l.n}`);
  }
});
test('difficulty rises: board size never shrinks within chapters & average depth grows per 20 levels', () => {
  const avg = [];
  for (let k = 0; k < 5; k++) {
    const slice = LEVELS.slice(k * 20, k * 20 + 20);
    avg.push(slice.reduce((s, l) => s + solve(l).layers * l.arrows.length, 0) / 20);
  }
  for (let k = 1; k < 5; k++) assert(avg[k] > avg[k - 1], `chapter ${k + 1} not harder than ${k}: ${avg.map((x) => x.toFixed(0))}`);
  for (let i = 1; i < 10; i++) assert(LEVELS[i].arrows.length >= LEVELS[i - 1].arrows.length, 'intro levels should grow');
});
test('levels 1-10 each have a tutorial message; chapters cover 1..100', () => {
  for (let n = 1; n <= 10; n++) assert(TUTORIALS[n] && TUTORIALS[n].text, `no tutorial for level ${n}`);
  eq(CHAPTERS[0].from, 1); eq(CHAPTERS[CHAPTERS.length - 1].to, 100);
});
test('levels 11-100 mix all four arrow directions', () => {
  for (const l of LEVELS.slice(10)) {
    const used = new Set(l.arrows.map((a) => a[2]));
    eq(used.size, 4, `level ${l.n} directions`);
  }
});
test('boards fit a phone (max 8 columns, max 10 rows)', () => {
  for (const l of LEVELS) assert(l.cols <= 8 && l.rows <= 10, `level ${l.n} too big`);
});

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
