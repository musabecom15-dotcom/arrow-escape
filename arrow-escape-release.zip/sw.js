// Service worker: caches every game file so the game works fully offline
// after the first visit. All paths are relative, so it works in a sub-folder
// (e.g. https://yourname.github.io/arrow-escape/).
//
// IMPORTANT: when you change ANY game file, bump CACHE_VERSION (e.g. v1.0.1)
// so players' phones download the new version.

const CACHE_VERSION = 'v1.0.0';
const CACHE_NAME = `arrow-escape-${CACHE_VERSION}`;

const PRECACHE = [
  './index.html',
  './manifest.webmanifest',
  './css/style.css',
  './js/app.js',
  './js/audio.js',
  './js/storage.js',
  './js/monetisation.js',
  './js/pwa.js',
  './js/core/board.js',
  './js/core/game.js',
  './js/core/generator.js',
  './js/core/progression.js',
  './js/core/rng.js',
  './js/core/solver.js',
  './js/data/levels.js',
  './js/data/tutorials.js',
  './js/ui/boardView.js',
  './js/ui/icons.js',
  './js/ui/particles.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await cache.addAll(PRECACHE);
      try { await cache.add('./'); } catch (e) { /* some hosts don't serve "./" - index.html is enough */ }
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('arrow-escape-') && k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // the game makes no external requests anyway

  // Cache first (instant + offline), fall back to network, then to index.html for page loads.
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      if (hit) return hit;
      return fetch(req)
        .then((res) => {
          if (res && res.ok && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(req, copy)).catch(() => {});
          }
          return res;
        })
        .catch(() => (req.mode === 'navigate' ? caches.match('./index.html') : Response.error()));
    })
  );
});
