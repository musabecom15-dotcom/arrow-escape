// Lightweight particle effects on a full-screen canvas (bursts + confetti).
// Only animates while particles exist, so it costs nothing when idle.

export class Particles {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.items = [];
    this.running = false;
    this.scale = 1; // 0.4 when "reduce motion" is on
    this.resize = this.resize.bind(this);
    window.addEventListener('resize', this.resize);
    this.resize();
  }

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.dpr = dpr;
    this.canvas.width = Math.round(window.innerWidth * dpr);
    this.canvas.height = Math.round(window.innerHeight * dpr);
    this.canvas.style.width = window.innerWidth + 'px';
    this.canvas.style.height = window.innerHeight + 'px';
  }

  /** Burst at screen point (x, y). dir = {dx, dy} pushes particles that way. */
  burst(x, y, color, dir = { dx: 0, dy: 0 }, count = 22) {
    const n = Math.max(4, Math.round(count * this.scale));
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 1.5 + Math.random() * 4.5;
      this.items.push({
        x, y,
        vx: Math.cos(a) * sp + dir.dx * 3.5,
        vy: Math.sin(a) * sp + dir.dy * 3.5,
        life: 1, decay: 0.022 + Math.random() * 0.025,
        size: 2.5 + Math.random() * 4.5,
        color: Math.random() < 0.25 ? '#ffffff' : color,
        shape: Math.random() < 0.5 ? 'c' : 's', rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.3,
        g: 0.06,
      });
    }
    this.start();
  }

  confetti(colors) {
    const n = Math.round(90 * this.scale);
    const w = window.innerWidth;
    for (let i = 0; i < n; i++) {
      this.items.push({
        x: Math.random() * w, y: -20 - Math.random() * 200,
        vx: (Math.random() - 0.5) * 2, vy: 2 + Math.random() * 3,
        life: 1, decay: 0.006 + Math.random() * 0.004,
        size: 5 + Math.random() * 6, color: colors[i % colors.length],
        shape: 'r', rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.25, g: 0.04,
      });
    }
    this.start();
  }

  start() {
    if (this.running) return;
    this.running = true;
    const step = () => {
      const { ctx, dpr } = this;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      const keep = [];
      for (const p of this.items) {
        p.x += p.vx; p.y += p.vy; p.vy += p.g; p.vx *= 0.985; p.rot += p.vr;
        p.life -= p.decay;
        if (p.life <= 0 || p.y > window.innerHeight + 40) continue;
        keep.push(p);
        ctx.globalAlpha = Math.max(0, Math.min(1, p.life));
        ctx.fillStyle = p.color;
        if (p.shape === 'c') {
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * 0.6, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          const h = p.shape === 'r' ? p.size * 0.5 : p.size;
          ctx.fillRect(-p.size / 2, -h / 2, p.size, h);
          ctx.restore();
        }
      }
      ctx.globalAlpha = 1;
      this.items = keep;
      if (keep.length) requestAnimationFrame(step);
      else { this.running = false; ctx.clearRect(0, 0, this.canvas.width, this.canvas.height); }
    };
    requestAnimationFrame(step);
  }
}
