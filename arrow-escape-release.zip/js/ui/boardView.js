// Draws the board with DOM elements + CSS animations and turns taps into game moves.

import { ARROW_SVG, BADGES, DIR_NAMES } from './icons.js';
import { DELTA } from '../core/board.js';

export class BoardView {
  constructor(boardEl, wrapEl, { onTap }) {
    this.el = boardEl;
    this.wrap = wrapEl;
    this.onTap = onTap;
    this.nodes = [];
    this.timers = new Map();
    this.cell = 48;
    this.reduceMotion = false;

    this.el.addEventListener('click', (e) => {
      const btn = e.target.closest('.arrow');
      if (!btn || btn.classList.contains('leaving')) return;
      this.onTap(Number(btn.dataset.id));
    });
    this.layout = this.layout.bind(this);
    window.addEventListener('resize', this.layout);
    window.addEventListener('orientationchange', () => setTimeout(this.layout, 200));
    if ('ResizeObserver' in window) new ResizeObserver(() => this.layout()).observe(this.wrap);
  }

  build(board) {
    this.board = board;
    for (const t of this.timers.values()) clearTimeout(t);
    this.timers.clear();
    this.el.innerHTML = '';
    this.el.style.setProperty('--rows', board.rows);
    this.el.style.setProperty('--cols', board.cols);
    // background cell dots
    const frag = document.createDocumentFragment();
    for (let r = 0; r < board.rows; r++) {
      for (let c = 0; c < board.cols; c++) {
        const d = document.createElement('div');
        d.className = 'cell';
        d.style.setProperty('--r', r); d.style.setProperty('--c', c);
        frag.appendChild(d);
      }
    }
    this.nodes = board.arrows.map((a, i) => {
      const b = document.createElement('button');
      b.className = `arrow dir-${a.d}`;
      b.dataset.id = a.id;
      b.style.setProperty('--r', a.r); b.style.setProperty('--c', a.c);
      b.style.setProperty('--delay', `${Math.min(i * 18, 500)}ms`);
      b.setAttribute('aria-label', `Arrow pointing ${DIR_NAMES[a.d]}, row ${a.r + 1}, column ${a.c + 1}`);
      b.innerHTML = `<span class="arrow-inner">${ARROW_SVG}<i class="badge">${BADGES[a.d]}</i></span>`;
      if (!a.alive) b.classList.add('gone');
      frag.appendChild(b);
      return b;
    });
    this.el.appendChild(frag);
    this.el.classList.remove('intro');
    void this.el.offsetWidth; // restart intro animation
    this.el.classList.add('intro');
    this.layout();
  }

  layout() {
    if (!this.board) return;
    const rect = this.wrap.getBoundingClientRect();
    if (rect.width < 10 || rect.height < 10) return;
    const pad = 28;
    const cell = Math.floor(Math.min((rect.width - pad) / this.board.cols, (rect.height - pad) / this.board.rows, 88));
    this.cell = Math.max(24, cell);
    this.el.style.setProperty('--cell', this.cell + 'px');
  }

  /** Screen point where an arrow leaves the board (for particles). */
  exitPoint(id) {
    const a = this.board.arrows[id];
    const r = this.el.getBoundingClientRect();
    const { dr, dc } = DELTA[a.d];
    const cx = r.left + 10 + (a.c + 0.5) * this.cell; // 10 = board padding
    const cy = r.top + 10 + (a.r + 0.5) * this.cell;
    if (dc === 1) return { x: r.right, y: cy };
    if (dc === -1) return { x: r.left, y: cy };
    if (dr === 1) return { x: cx, y: r.bottom };
    return { x: cx, y: r.top };
  }

  centerPoint(id) {
    const a = this.board.arrows[id];
    const r = this.el.getBoundingClientRect();
    return { x: r.left + 10 + (a.c + 0.5) * this.cell, y: r.top + 10 + (a.r + 0.5) * this.cell };
  }

  escape(id, distance) {
    const node = this.nodes[id];
    const a = this.board.arrows[id];
    const { dr, dc } = DELTA[a.d];
    const travel = (distance + 1.5) * this.cell;
    const ms = this.reduceMotion ? 160 : Math.round(170 + distance * 45);
    node.classList.remove('hint');
    node.classList.add('leaving');
    node.style.transition = `transform ${ms}ms cubic-bezier(.55,0,.85,.35), opacity ${ms}ms ease-in`;
    node.style.transform = `translate(${dc * travel}px, ${dr * travel}px)`;
    node.style.opacity = '0';
    const t = setTimeout(() => { node.classList.add('gone'); this.timers.delete(id); }, ms + 20);
    this.timers.set(id, t);
    return ms;
  }

  restore(id) {
    const node = this.nodes[id];
    if (this.timers.has(id)) { clearTimeout(this.timers.get(id)); this.timers.delete(id); }
    node.style.transition = 'none';
    node.style.transform = '';
    node.style.opacity = '';
    node.classList.remove('leaving', 'gone', 'pop');
    void node.offsetWidth;
    node.style.transition = '';
    node.classList.add('pop');
  }

  blocked(id, blockerId) {
    const node = this.nodes[id];
    const blk = this.nodes[blockerId];
    const a = this.board.arrows[id];
    node.classList.remove('nudge-U', 'nudge-R', 'nudge-D', 'nudge-L', 'shake');
    blk && blk.classList.remove('bump');
    void node.offsetWidth;
    node.classList.add(`nudge-${a.d}`, 'shake');
    blk && blk.classList.add('bump');
    setTimeout(() => {
      node.classList.remove(`nudge-${a.d}`, 'shake');
      blk && blk.classList.remove('bump');
    }, 600);
  }

  showHint(id) {
    this.clearHint();
    if (id >= 0 && this.nodes[id]) this.nodes[id].classList.add('hint');
  }

  clearHint() {
    this.nodes.forEach((n) => n.classList.remove('hint'));
  }
}
