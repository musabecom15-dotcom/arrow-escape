// Original line icons drawn as inline SVG (no icon fonts or external files).
const S = (body, vb = '0 0 24 24') =>
  `<svg viewBox="${vb}" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${body}</svg>`;

export const ICONS = {
  back: S('<path d="M15 5l-7 7 7 7"/>'),
  play: S('<path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/>'),
  grid: S('<rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.8"/>'),
  calendar: S('<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/><circle cx="12" cy="15" r="1.6" fill="currentColor"/>'),
  gear: S('<circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>'),
  undo: S('<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 010 11H11"/>'),
  bulb: S('<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 00-3.6 10.8c.8.6 1.1 1.3 1.1 2.2h5c0-.9.3-1.6 1.1-2.2A6 6 0 0012 3z"/>'),
  restart: S('<path d="M4 12a8 8 0 102.4-5.7"/><path d="M4 4v4.5h4.5"/>'),
  heart: '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M12 21s-7.5-4.6-9.6-9.3C.9 8.3 3 4.5 6.7 4.5c2.2 0 3.6 1.2 5.3 3.2 1.7-2 3.1-3.2 5.3-3.2 3.7 0 5.8 3.8 4.3 7.2C19.5 16.4 12 21 12 21z" fill="currentColor"/></svg>',
  star: '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.4l-5.8 3.1 1.1-6.5L2.6 9.4l6.5-.9z" fill="currentColor" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>',
  lock: S('<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 018 0v2.5"/>'),
  check: S('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
};

/** Replace every <span data-icon="name"> in a container with its SVG. */
export function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach((el) => {
    const name = el.getAttribute('data-icon');
    if (ICONS[name] && !el.firstChild) {
      el.innerHTML = ICONS[name];
      el.classList.add('ico');
    }
  });
}

/** Arrow tile artwork: a bold rounded arrow pointing UP (rotated with CSS). */
export const ARROW_SVG =
  '<svg class="arrow-glyph" viewBox="0 0 100 100" aria-hidden="true" focusable="false">' +
  '<path d="M50 16 L80 47 L61 47 L61 82 Q61 85 58 85 L42 85 Q39 85 39 82 L39 47 L20 47 Z" fill="currentColor" stroke="currentColor" stroke-width="7" stroke-linejoin="round"/></svg>';

/** Colourblind shape badges (one distinct shape per direction). */
export const BADGES = {
  U: '<svg viewBox="0 0 10 10" aria-hidden="true"><path d="M5 1L9.3 8.6H.7z" fill="currentColor"/></svg>',
  R: '<svg viewBox="0 0 10 10" aria-hidden="true"><rect x="1.3" y="1.3" width="7.4" height="7.4" rx="1" fill="currentColor"/></svg>',
  D: '<svg viewBox="0 0 10 10" aria-hidden="true"><circle cx="5" cy="5" r="4" fill="currentColor"/></svg>',
  L: '<svg viewBox="0 0 10 10" aria-hidden="true"><path d="M5 .6L9.4 5 5 9.4.6 5z" fill="currentColor"/></svg>',
};

export const DIR_NAMES = { U: 'up', R: 'right', D: 'down', L: 'left' };
