// Short tutorial cards shown at the start of levels 1-10.
export const TUTORIALS = {
  1: { title: 'Tap to launch', text: 'Tap an arrow to send it flying off the board. Clear every arrow to win!' },
  2: { title: 'Clear runway', text: 'An arrow can only escape if nothing is in its way, all the way to the edge.' },
  3: { title: 'Careful!', text: 'Tapping a blocked arrow costs a life \u2764 You have 3 per level.' },
  4: { title: 'Order matters', text: 'Free the arrows that are in the way first, then the others can follow.' },
  5: { title: 'Need a clue?', text: 'Tap Hint to highlight a safe move. Using a hint limits you to 2 stars.' },
  6: { title: 'Undo', text: 'Changed your mind? Undo brings back your last arrow. It does not give lives back.' },
  7: { title: 'Earn stars', text: 'No mistakes and no hints = 3 stars. Each mistake costs a star.' },
  8: { title: 'Look ahead', text: 'Scan each row and column. Arrows pointing at an empty edge are safe.' },
  9: { title: 'Chain reactions', text: 'One move can unlock several arrows. Find the key arrow!' },
  10: { title: 'You\u2019re ready', text: 'That\u2019s everything! Boards grow from here. Try the Daily Challenge too.' },
};
