// ARROW ESCAPE - app entry point: screens, menus and wiring between modules.

import { LEVELS } from './data/levels.js';
import { TUTORIALS } from './data/tutorials.js';
import { GameSession } from './core/game.js';
import { generateLevel } from './core/generator.js';
import { CHAPTERS, LEVEL_COUNT, dateKey, dailyParams } from './core/progression.js';
import * as Store from './storage.js';
import { sfx, unlockAudio, setSoundEnabled } from './audio.js';
import { Monetisation } from './monetisation.js';
import { registerServiceWorker } from './pwa.js';
import { BoardView } from './ui/boardView.js';
import { Particles } from './ui/particles.js';
import { ICONS, BADGES, ARROW_SVG, hydrateIcons } from './ui/icons.js';

export const VERSION = '1.0.0';

const $ = (id) => document.getElementById(id);
const DIR_COLORS = { U: '#4F7DFF', R: '#FF7A33', D: '#14B89A', L: '#9B5CFF' };
const CB_COLORS = { U: '#0072B2', R: '#E69F00', D: '#009E73', L: '#CC79A7' };

const state = {
  screen: 'splash',
  session: null,
  mode: 'level', // 'level' | 'daily'
  levelNumber: 1,
  dailyKey: null,
  hintId: -1,
  busy: false,
};

let view, fx;

// ---------- helpers ----------
function colors() { return Store.getSettings().colorblind ? CB_COLORS : DIR_COLORS; }

function haptic(ms) {
  if (!Store.getSettings().haptics) return;
  const ua = navigator.userActivation;
  if (ua && !ua.hasBeenActive) return; // browsers block vibration before the first real tap
  try { navigator.vibrate && navigator.vibrate(ms); } catch { /* not supported (iOS) */ }
}

let toastTimer = 0;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1800);
}

function prefersDark() {
  try { return window.matchMedia('(prefers-color-scheme: dark)').matches; } catch { return false; }
}
function prefersReducedMotion() {
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; }
}

function applySettings() {
  const s = Store.getSettings();
  const dark = s.dark === null ? prefersDark() : s.dark;
  const rm = s.reducedMotion === null ? prefersReducedMotion() : s.reducedMotion;
  document.body.classList.toggle('dark', !!dark);
  document.body.classList.toggle('colorblind', !!s.colorblind);
  document.body.classList.toggle('reduce-motion', !!rm);
  setSoundEnabled(s.sound);
  if (view) view.reduceMotion = !!rm;
  if (fx) fx.scale = rm ? 0.35 : 1;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', dark ? '#14112B' : '#6C5CE7');
  $('set-sound').checked = !!s.sound;
  $('set-haptics').checked = !!s.haptics;
  $('set-dark').checked = !!dark;
  $('set-colorblind').checked = !!s.colorblind;
  $('set-motion').checked = !!rm;
}

function chapterFor(n) { return CHAPTERS.find((c) => n >= c.from && n <= c.to); }

// ---------- navigation (with Android back-button support) ----------
let navDepth = 0; // how many history entries we pushed
function show(name, { push = true } = {}) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === `screen-${name}`));
  state.screen = name;
  if (name !== 'game') hideOverlay();
  if (name === 'home') renderHome();
  if (name === 'levels') renderLevels();
  if (push) {
    try { history.pushState({ screen: name }, ''); navDepth++; } catch { /* sandboxed iframe */ }
  }
  if (name === 'game') requestAnimationFrame(() => view.layout());
}

window.addEventListener('popstate', (e) => {
  navDepth = Math.max(0, navDepth - 1);
  const target = (e.state && e.state.screen) || 'home';
  if (state.screen === 'game' && !$('overlay').classList.contains('hidden')) hideOverlay();
  show(target === 'game' || target === 'splash' ? (state.mode === 'daily' ? 'home' : 'levels') : target, { push: false });
});

function goBack() {
  sfx.click();
  // Use the browser history when we can, so the phone's back gesture and our button agree.
  if (navDepth > 0) { history.back(); return; }
  show(state.screen === 'game' && state.mode !== 'daily' ? 'levels' : 'home', { push: false });
}

// ---------- home ----------
function renderHome() {
  const s = Store.load();
  const total = Store.totalStars();
  $('home-stars').innerHTML = `${ICONS.star}<span>${total} / ${LEVEL_COUNT * 3}</span>`;
  const next = Math.min(s.unlocked, LEVEL_COUNT);
  $('btn-play-label').textContent = s.stars[1] ? `Continue \u00b7 Level ${next}` : 'Play';
  const key = dateKey();
  const done = s.daily[key];
  $('daily-status').textContent = done ? `Done ${'\u2605'.repeat(done)}` : 'New today';
  $('daily-status').classList.toggle('done', !!done);
}

// ---------- level select ----------
function renderLevels() {
  const s = Store.load();
  $('levels-stars').innerHTML = `${ICONS.star}<span>${Store.totalStars()} / ${LEVEL_COUNT * 3}</span>`;
  const list = $('level-list');
  let html = '';
  for (const ch of CHAPTERS) {
    let chStars = 0;
    for (let n = ch.from; n <= ch.to; n++) chStars += s.stars[n] || 0;
    const locked = ch.from > s.unlocked;
    html += `<div class="chapter${locked ? ' locked' : ''}"><div class="chapter-head"><h3>${ch.name}</h3><span>${ch.from}\u2013${ch.to} \u00b7 ${chStars}/${(ch.to - ch.from + 1) * 3}\u2605</span></div><div class="level-grid">`;
    for (let n = ch.from; n <= ch.to; n++) {
      const st = s.stars[n] || 0;
      const isLocked = n > s.unlocked;
      const isCurrent = n === s.unlocked && !st;
      const stars = [0, 1, 2].map((i) => `<i class="${i < st ? 'on' : ''}">${ICONS.star}</i>`).join('');
      html += isLocked
        ? `<button class="lvl locked" disabled aria-label="Level ${n} locked">${ICONS.lock}</button>`
        : `<button class="lvl${isCurrent ? ' current' : ''}${st === 3 ? ' perfect' : ''}" data-level="${n}" aria-label="Level ${n}, ${st} stars"><b>${n}</b><span class="lvl-stars">${stars}</span></button>`;
    }
    html += '</div></div>';
  }
  list.innerHTML = html;
  const cur = list.querySelector('.lvl.current') || list.querySelector(`[data-level="${Math.min(s.unlocked, LEVEL_COUNT)}"]`);
  if (cur) requestAnimationFrame(() => cur.scrollIntoView({ block: 'center' }));
}

// ---------- gameplay ----------
function startLevel(n) {
  state.mode = 'level';
  state.levelNumber = n;
  const lv = LEVELS[n - 1];
  beginSession(lv, `Level ${n}`, chapterFor(n).name);
  showTutorial(TUTORIALS[n]);
  if (n === 1) setTimeout(() => { if (state.session && state.session.moves === 0) view.showHint(state.session.hint({ count: false })); }, 900);
}

function startDaily() {
  state.mode = 'daily';
  state.dailyKey = dateKey();
  const lv = generateLevel(dailyParams(state.dailyKey));
  const d = new Date();
  const label = d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  beginSession(lv, 'Daily Challenge', label);
  showTutorial(null);
}

function beginSession(level, title, sub) {
  state.session = new GameSession(level);
  state.hintId = -1;
  Store.recordPlay();
  $('hud-level').textContent = title;
  $('hud-sub').textContent = sub;
  show('game', { push: state.screen !== 'game' }); // "Next level" doesn't stack history
  view.build(state.session.board);
  updateHud();
}

function showTutorial(t) {
  const box = $('tutorial');
  if (!t) { box.classList.add('hidden'); return; }
  $('tut-title').textContent = t.title;
  $('tut-text').textContent = t.text;
  box.classList.remove('hidden');
  requestAnimationFrame(() => view.layout());
}

function updateHud(lostLife = false) {
  const g = state.session;
  const hearts = [];
  for (let i = 0; i < g.maxLives; i++) {
    const on = i < g.lives;
    const breaking = lostLife && i === g.lives;
    hearts.push(`<i class="heart${on ? '' : ' empty'}${breaking ? ' breaking' : ''}">${ICONS.heart}</i>`);
  }
  $('hud-hearts').innerHTML = hearts.join('');
  $('hud-hearts').setAttribute('aria-label', `${g.lives} lives left`);
  const done = g.total - g.remaining;
  $('hud-progress').style.width = `${(done / g.total) * 100}%`;
  $('hud-count').textContent = `${g.remaining} arrow${g.remaining === 1 ? '' : 's'} left`;
  $('btn-undo').disabled = !g.canUndo();
  $('btn-hint').disabled = g.status !== 'playing';
}

function onArrowTap(id) {
  const g = state.session;
  if (!g || g.status !== 'playing') return;
  const res = g.tap(id);
  if (res.type === 'ignored') return;
  view.clearHint();
  if (res.type === 'escaped') {
    sfx.whoosh();
    haptic(8);
    const ms = view.escape(id, res.distance);
    const a = g.board.arrows[id];
    const dirs = { U: { dx: 0, dy: -1 }, D: { dx: 0, dy: 1 }, L: { dx: -1, dy: 0 }, R: { dx: 1, dy: 0 } };
    setTimeout(() => {
      const p = view.exitPoint(id);
      fx.burst(p.x, p.y, colors()[a.d], dirs[a.d]);
    }, Math.max(60, ms * 0.55));
    updateHud();
    if (res.won) setTimeout(onWin, ms + 250);
  } else if (res.type === 'blocked') {
    sfx.blocked();
    haptic([30, 40, 30]);
    view.blocked(id, res.blocker);
    const p = view.centerPoint(res.blocker);
    fx.burst(p.x, p.y, '#FF4D6D', { dx: 0, dy: 0 }, 10);
    $('board-wrap').classList.remove('jolt'); void $('board-wrap').offsetWidth; $('board-wrap').classList.add('jolt');
    updateHud(true);
    if (res.lost) setTimeout(onLose, 650);
    else toast(res.lives === 1 ? 'Blocked! Last life \u2764' : 'Blocked! That arrow\u2019s path isn\u2019t clear');
  }
}

function onUndo() {
  const id = state.session && state.session.undo();
  if (id === undefined || id < 0) return;
  sfx.undo();
  view.clearHint();
  view.restore(id);
  updateHud();
}

function onHint() {
  const g = state.session;
  if (!g || g.status !== 'playing') return;
  const firstHint = g.hintsUsed === 0;
  const id = g.hint();
  if (id < 0) return;
  sfx.hint();
  view.showHint(id);
  if (firstHint) toast('Hint used: max 2 stars this time');
}

function onRestart() {
  if (!state.session) return;
  sfx.click();
  hideOverlay();
  state.session.reset();
  view.build(state.session.board);
  updateHud();
}

function starRow(n, animate = true) {
  return `<div class="star-row">${[0, 1, 2]
    .map((i) => `<i class="big-star${i < n ? ' on' : ''}${animate ? ' anim' : ''}" style="--i:${i}">${ICONS.star}</i>`)
    .join('')}</div>`;
}

function onWin() {
  const g = state.session;
  const stars = g.stars();
  const c = colors();
  sfx.win();
  fx.confetti([c.U, c.R, c.D, c.L, '#FFD24D']);
  for (let i = 0; i < stars; i++) setTimeout(() => sfx.star(i), 350 + i * 220);
  let title = 'Level Complete!';
  let extra = '';
  let buttons = '';
  if (state.mode === 'daily') {
    Store.recordDailyWin(state.dailyKey, stars);
    title = 'Daily Cleared!';
    extra = '<p class="modal-sub">Come back tomorrow for a new puzzle.</p>';
    buttons = `<button class="btn btn-primary" data-act="home">Home</button><button class="btn btn-ghost" data-act="replay">Play again</button>`;
  } else {
    const n = state.levelNumber;
    const res = Store.recordWin(n, stars, LEVEL_COUNT);
    if (n === LEVEL_COUNT) {
      title = 'All 100 Cleared!';
      extra = `<p class="modal-sub">You are an Arrow Escape master. Try for 3 stars everywhere!</p>`;
      buttons = `<button class="btn btn-primary" data-act="levels">Levels</button><button class="btn btn-ghost" data-act="replay">Replay</button>`;
    } else {
      extra = res.improved && !res.firstClear ? '<p class="modal-sub">New best!</p>' : '';
      buttons = `<button class="btn btn-primary" data-act="next">Next level ${ICONS.play}</button><div class="btn-pair"><button class="btn btn-ghost" data-act="replay">Replay</button><button class="btn btn-ghost" data-act="levels">Levels</button></div>`;
    }
  }
  const stats = `<div class="stats"><div><b>${g.mistakes}</b><small>mistakes</small></div><div><b>${g.hintsUsed}</b><small>hints</small></div><div><b>${g.total}</b><small>arrows</small></div></div>`;
  showOverlay(`<div class="modal-badge win">${ICONS.check}</div><h2>${title}</h2>${starRow(stars)}${extra}${stats}<div class="modal-actions">${buttons}</div>`);
}

function onLose() {
  sfx.lose();
  Store.recordLoss();
  const tip = 'Every board can be cleared. Look for arrows with nothing in front of them.';
  const rewarded = Monetisation.isRewardedAvailable()
    ? '<button class="btn btn-ghost" data-act="rewarded-life">Watch a video for +1 life</button>'
    : ''; // v1: never shown (no ads)
  const back = state.mode === 'daily' ? 'home' : 'levels';
  showOverlay(`<div class="modal-badge lose">${ICONS.heart}</div><h2>Out of lives</h2><p class="modal-sub">${tip}</p><div class="modal-actions"><button class="btn btn-primary" data-act="replay">${ICONS.restart} Try again</button>${rewarded}<button class="btn btn-ghost" data-act="${back}">${back === 'home' ? 'Home' : 'Levels'}</button></div>`);
}

function showOverlay(html) {
  $('toast').classList.remove('show');
  $('modal').innerHTML = html;
  $('overlay').classList.remove('hidden');
  const first = $('modal').querySelector('button');
  if (first) setTimeout(() => first.focus({ preventScroll: true }), 50);
}
function hideOverlay() { $('overlay').classList.add('hidden'); }

function confirmDialog(title, text, okLabel, onOk) {
  showOverlay(`<h2>${title}</h2><p class="modal-sub">${text}</p><div class="modal-actions"><button class="btn btn-danger" data-act="confirm-ok">${okLabel}</button><button class="btn btn-ghost" data-act="close">Cancel</button></div>`);
  state.confirmOk = onOk;
}

$('overlay').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  sfx.click();
  const act = btn.dataset.act;
  if (act === 'next') { hideOverlay(); startLevel(Math.min(state.levelNumber + 1, LEVEL_COUNT)); }
  else if (act === 'replay') { onRestart(); }
  else if (act === 'levels') { hideOverlay(); show('levels'); }
  else if (act === 'home') { hideOverlay(); show('home'); }
  else if (act === 'close') { hideOverlay(); }
  else if (act === 'confirm-ok') { hideOverlay(); state.confirmOk && state.confirmOk(); }
  else if (act === 'rewarded-life') {
    const ok = await Monetisation.showRewarded('extra-life');
    if (ok) toast('Thanks!');
  }
});

// ---------- settings ----------
function initSettings() {
  const bind = (id, key, after) => $(id).addEventListener('change', (e) => {
    Store.setSetting(key, e.target.checked);
    applySettings();
    after && after();
    sfx.click();
  });
  bind('set-sound', 'sound');
  bind('set-haptics', 'haptics', () => haptic(20));
  bind('set-dark', 'dark');
  bind('set-colorblind', 'colorblind');
  bind('set-motion', 'reducedMotion');
  $('btn-reset').addEventListener('click', () => {
    sfx.click();
    confirmDialog('Reset progress?', 'This deletes all stars and locks levels again. Settings are kept. This cannot be undone.', 'Reset', () => {
      Store.resetProgress();
      toast('Progress reset');
    });
  });
  $('legend').innerHTML = ['U', 'R', 'D', 'L']
    .map((d) => `<div class="legend-item"><span class="arrow mini dir-${d}"><span class="arrow-inner">${ARROW_SVG}<i class="badge">${BADGES[d]}</i></span></span><small>${{ U: 'Up', R: 'Right', D: 'Down', L: 'Left' }[d]}</small></div>`)
    .join('');
  const saveNote = Store.isPersistent() ? 'Progress is saved on this device.' : 'Storage is blocked here, so progress lasts only until you close the page.';
  $('about-text').innerHTML = `Arrow Escape v${VERSION} &middot; ${saveNote}<br>Original game. All graphics and sounds are generated by code.`;
}

// ---------- boot ----------
function boot() {
  Store.load();
  hydrateIcons();
  fx = new Particles($('fx'));
  view = new BoardView($('board'), $('board-wrap'), { onTap: onArrowTap });
  applySettings();
  initSettings();

  try {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applySettings);
  } catch { /* older Safari */ }

  // Unlock audio on the first touch (required by iOS Safari).
  const unlock = () => unlockAudio();
  window.addEventListener('pointerdown', unlock, { passive: true });
  window.addEventListener('keydown', unlock);

  // Block pinch / double-tap zoom gestures on iOS (we have our own scaling).
  document.addEventListener('gesturestart', (e) => e.preventDefault());
  document.addEventListener('dblclick', (e) => e.preventDefault(), { passive: false });

  // Buttons
  document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', goBack));
  $('btn-game-back').addEventListener('click', goBack);
  $('btn-play').addEventListener('click', () => { sfx.click(); startLevel(Math.min(Store.load().unlocked, LEVEL_COUNT)); });
  $('btn-levels').addEventListener('click', () => { sfx.click(); show('levels'); });
  $('btn-daily').addEventListener('click', () => { sfx.click(); startDaily(); });
  $('btn-settings').addEventListener('click', () => { sfx.click(); show('settings'); });
  $('level-list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-level]');
    if (b) { sfx.click(); startLevel(Number(b.dataset.level)); }
  });
  $('btn-undo').addEventListener('click', onUndo);
  $('btn-hint').addEventListener('click', onHint);
  $('btn-restart').addEventListener('click', onRestart);
  $('tut-close').addEventListener('click', () => { sfx.click(); showTutorial(null); });

  // Keyboard shortcuts (desktop): U = undo, H = hint, R = restart, Esc = back
  window.addEventListener('keydown', (e) => {
    if (state.screen !== 'game' || !$('overlay').classList.contains('hidden')) return;
    const k = e.key.toLowerCase();
    if (k === 'u' || (k === 'z' && (e.ctrlKey || e.metaKey))) onUndo();
    else if (k === 'h') onHint();
    else if (k === 'r') onRestart();
    else if (k === 'escape') goBack();
  });

  // Splash -> home
  try { history.replaceState({ screen: 'home' }, ''); } catch { /* ignore */ }
  let left = false;
  const leaveSplash = () => {
    if (left) return;
    left = true;
    show('home', { push: false });
  };
  $('screen-splash').addEventListener('click', leaveSplash);
  setTimeout(leaveSplash, 1600);

  registerServiceWorker();
}

boot();
