// Saves progress and settings in localStorage.
// If storage is unavailable (private mode, some embedded iframes), the game
// still works and simply keeps progress in memory for this session.

const KEY = 'arrowEscape.save.v1';

const DEFAULTS = {
  version: 1,
  unlocked: 1, // highest level the player may open
  stars: {}, // { "12": 3 }
  daily: {}, // { "2026-11-13": 2 }
  settings: {
    sound: true,
    haptics: true,
    dark: null, // null = follow the phone's setting
    colorblind: false,
    reducedMotion: null, // null = follow the phone's setting
  },
  wallet: { bonusHints: 0 }, // reserved for future (e.g. rewarded hint packs)
  cosmetics: { theme: 'default', owned: ['default'] }, // reserved for future themes
  stats: { played: 0, wins: 0, losses: 0 },
};

let memory = null;
let persistent = true;

function deepMerge(base, extra) {
  const out = Array.isArray(base) ? base.slice() : { ...base };
  if (!extra || typeof extra !== 'object') return out;
  for (const k of Object.keys(extra)) {
    const v = extra[k];
    if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      out[k] = deepMerge(base[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

export function load() {
  if (memory) return memory;
  let saved = null;
  try {
    const raw = window.localStorage.getItem(KEY);
    saved = raw ? JSON.parse(raw) : null;
  } catch {
    persistent = false;
  }
  memory = deepMerge(DEFAULTS, saved);
  return memory;
}

export function save() {
  if (!memory) return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(memory));
    persistent = true;
  } catch {
    persistent = false;
  }
}

export function isPersistent() { return persistent; }

export function getSettings() { return load().settings; }

export function setSetting(name, value) {
  load().settings[name] = value;
  save();
}

/** Record a finished level. Returns { improved, firstClear }. */
export function recordWin(levelNumber, stars, totalLevels) {
  const s = load();
  const prev = s.stars[levelNumber] || 0;
  if (stars > prev) s.stars[levelNumber] = stars;
  if (levelNumber >= s.unlocked && levelNumber < totalLevels) s.unlocked = levelNumber + 1;
  s.stats.wins++;
  save();
  return { improved: stars > prev, firstClear: prev === 0 };
}

export function recordDailyWin(key, stars) {
  const s = load();
  if ((s.daily[key] || 0) < stars) s.daily[key] = stars;
  s.stats.wins++;
  save();
}

export function recordLoss() { load().stats.losses++; save(); }
export function recordPlay() { load().stats.played++; save(); }

export function totalStars() {
  return Object.values(load().stars).reduce((a, b) => a + b, 0);
}

export function resetProgress() {
  const keepSettings = { ...load().settings };
  memory = deepMerge(DEFAULTS, { settings: keepSettings });
  memory.stars = {};
  memory.daily = {};
  save();
}
