// Reverse-construction puzzle generator. Pure logic: no DOM access.
//
// HOW IT GUARANTEES A SOLUTION
// We start from an EMPTY board and add arrows one at a time. A new arrow may
// only be placed if ITS OWN path to the edge is clear at the moment it is
// placed. Arrows added later may sit in its path, but they are removed before
// it when we play the placements backwards. So "remove arrows in reverse
// placement order" is always a valid solution. The solver then double-checks.
//
// HOW IT MAKES PUZZLES INTERESTING
// We prefer cells that lie in the path of many earlier arrows (so the new arrow
// BLOCKS them), which creates chains of dependencies. A difficulty "bias"
// controls how often we pick the most blocking spot versus a random one.

import { mulberry32 } from './rng.js';
import { DIRS, rayCells } from './board.js';
import { solve } from './solver.js';

function constructOnce(rng, rows, cols, count, bias) {
  const n = rows * cols;
  const occupied = new Uint8Array(n);
  const cover = new Uint16Array(n); // how many placed arrows' rays cross this cell
  const placed = []; // { r, c, d }
  const dirCount = [0, 0, 0, 0]; // keeps the four directions roughly balanced

  while (placed.length < count) {
    // Gather every legal (cell, direction) whose path to the edge is clear right now.
    const cands = [];
    for (let idx = 0; idx < n; idx++) {
      if (occupied[idx]) continue;
      const r = (idx / cols) | 0, c = idx % cols;
      for (let k = 0; k < 4; k++) {
        const d = DIRS[k];
        const ray = rayCells(rows, cols, r, c, d);
        let clear = true;
        for (const p of ray) if (occupied[p]) { clear = false; break; }
        if (!clear) continue;
        // Score: blocking earlier arrows matters most; long runways a little.
        // Directions already over-used get a penalty so every board mixes all four.
        const balance = (dirCount[k] - placed.length / 4) * 0.9;
        const score = cover[idx] * 2 + ray.length * 0.35 - balance + rng() * 1.5;
        cands.push({ idx, r, c, k, ray, score });
      }
    }
    if (cands.length === 0) break;
    let pick;
    if (rng() < bias) {
      pick = cands[0];
      for (const cd of cands) if (cd.score > pick.score) pick = cd;
    } else {
      pick = cands[Math.floor(rng() * cands.length)];
    }
    occupied[pick.idx] = 1;
    for (const p of pick.ray) cover[p]++;
    dirCount[pick.k]++;
    placed.push({ r: pick.r, c: pick.c, k: pick.k });
  }
  return placed;
}

/**
 * Generate a level deterministically.
 * params: { rows, cols, count, bias (0..1), targetLayers, seed, attempts }
 * Returns { rows, cols, seed, arrows: [[r,c,dirIndex]...], stats: { layers, initiallyFree, count } }
 */
export function generateLevel(params) {
  const { rows, cols, count, bias, targetLayers, seed } = params;
  const attempts = params.attempts || 10;
  const rng = mulberry32(seed);
  let best = null;
  for (let t = 0; t < attempts; t++) {
    const placed = constructOnce(rng, rows, cols, count, bias);
    if (placed.length < Math.min(count, 2)) continue;
    // Shuffle-free stable ordering: sort by position so ids read left->right, top->bottom.
    placed.sort((a, b) => a.r - b.r || a.c - b.c);
    const level = { rows, cols, arrows: placed.map((p) => [p.r, p.c, p.k]) };
    const res = solve(level);
    if (!res.solvable) continue; // should never happen; the solver is our safety net
    const shortfall = count - placed.length;
    const metric =
      Math.abs(res.layers - targetLayers) * 10 + shortfall * 3 + res.initiallyFree / placed.length;
    if (!best || metric < best.metric) {
      best = { metric, level, res };
    }
  }
  if (!best) throw new Error(`Generator failed for seed ${seed}`);
  return {
    rows,
    cols,
    seed,
    arrows: best.level.arrows,
    stats: { layers: best.res.layers, initiallyFree: best.res.initiallyFree, count: best.level.arrows.length },
  };
}
