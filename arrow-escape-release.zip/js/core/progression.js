// Difficulty progression for the 100 levels + the daily challenge. Pure logic.

import { hashString } from './rng.js';

export const LEVEL_COUNT = 100;

// Hand-tuned gentle start (levels 1-10 teach the rules).
const INTRO = [
  // rows, cols, count, bias, targetLayers
  [3, 3, 3, 0.0, 1],
  [3, 3, 4, 0.6, 2],
  [3, 3, 5, 0.7, 2],
  [4, 4, 6, 0.6, 2],
  [4, 4, 7, 0.7, 3],
  [4, 4, 8, 0.7, 3],
  [4, 4, 9, 0.75, 3],
  [4, 4, 10, 0.75, 4],
  [4, 4, 11, 0.8, 4],
  [4, 4, 12, 0.8, 4],
];

// Board sizes grow in "chapters". Portrait-friendly: never wider than 8 columns.
const BANDS = [
  { from: 11, to: 20, rows: 5, cols: 5 },
  { from: 21, to: 35, rows: 6, cols: 5 },
  { from: 36, to: 50, rows: 7, cols: 6 },
  { from: 51, to: 65, rows: 8, cols: 6 },
  { from: 66, to: 80, rows: 8, cols: 7 },
  { from: 81, to: 90, rows: 9, cols: 7 },
  { from: 91, to: 100, rows: 10, cols: 8 },
];

export const CHAPTERS = [
  { name: 'Warm-Up', from: 1, to: 20 },
  { name: 'Crossroads', from: 21, to: 40 },
  { name: 'Gridlock', from: 41, to: 60 },
  { name: 'Labyrinth', from: 61, to: 80 },
  { name: 'Mastermind', from: 81, to: 100 },
];

/** Fixed seed for level n (never change these once published, or levels change!). */
export function levelSeed(n) {
  return hashString(`arrow-escape-level-${n}`);
}

/** Generator parameters for level n (1-based). */
export function levelParams(n) {
  if (n < 1 || n > LEVEL_COUNT) throw new Error(`No level ${n}`);
  if (n <= INTRO.length) {
    const [rows, cols, count, bias, targetLayers] = INTRO[n - 1];
    return { rows, cols, count, bias, targetLayers, seed: levelSeed(n), attempts: 12 };
  }
  const band = BANDS.find((b) => n >= b.from && n <= b.to);
  const inBand = (n - band.from) / Math.max(1, band.to - band.from); // 0..1 inside chapter
  const overall = (n - 11) / (LEVEL_COUNT - 11); // 0..1 across levels 11-100
  const cells = band.rows * band.cols;
  const density = 0.62 + 0.18 * inBand + 0.1 * overall; // 62% -> ~90% full
  const count = Math.round(cells * Math.min(0.92, density));
  const bias = Math.min(0.95, 0.6 + 0.35 * overall);
  const targetLayers = Math.round(4 + 10 * overall + 2 * inBand);
  return { rows: band.rows, cols: band.cols, count, bias, targetLayers, seed: levelSeed(n), attempts: 14 };
}

/** Local date key like "2026-11-13". */
export function dateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/** Daily challenge parameters: same for everyone on the same date. */
export function dailyParams(key) {
  const seed = hashString(`arrow-escape-daily-${key}`);
  const sizes = [
    [7, 6], [8, 6], [8, 7], [7, 7],
  ];
  const [rows, cols] = sizes[seed % sizes.length];
  const count = Math.round(rows * cols * 0.8);
  return { rows, cols, count, bias: 0.85, targetLayers: 10, seed, attempts: 10 };
}
