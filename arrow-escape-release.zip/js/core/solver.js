// Solver. Pure logic: no DOM access.
//
// KEY FACT: removing an arrow can only ever CLEAR paths, never block them.
// So if an arrow can escape now, it can still escape after any other removal.
// That means a simple greedy strategy ("remove any free arrow, repeat") is a
// COMPLETE solver: if it gets stuck, no order of moves could ever clear the board.

import { createBoard, cloneBoard, freeArrows, removeArrow } from './board.js';

/**
 * Solve a level (or a live board).
 * Returns { solvable, order, layers, initiallyFree, remaining }
 *  - order: one valid sequence of arrow ids that clears the board
 *  - layers: number of "waves" needed if you removed every free arrow at once
 *            each wave (a good measure of puzzle depth / difficulty)
 */
export function solve(levelOrBoard) {
  const board = levelOrBoard.cells ? cloneBoard(levelOrBoard) : createBoard(levelOrBoard);
  const order = [];
  let layers = 0;
  let initiallyFree = -1;
  while (board.alive > 0) {
    const free = freeArrows(board);
    if (initiallyFree < 0) initiallyFree = free.length;
    if (free.length === 0) break;
    for (const id of free) { removeArrow(board, id); order.push(id); }
    layers++;
  }
  if (initiallyFree < 0) initiallyFree = 0;
  return { solvable: board.alive === 0, order, layers, initiallyFree, remaining: board.alive };
}

/** Check that a specific sequence of taps clears the board without any blocked move. */
export function verifySolution(level, order) {
  const board = createBoard(level);
  for (const id of order) {
    const free = freeArrows(board);
    if (!free.includes(id)) return false;
    removeArrow(board, id);
  }
  return board.alive === 0;
}
