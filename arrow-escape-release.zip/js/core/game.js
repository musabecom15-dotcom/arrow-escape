// A single play session of one level: lives, moves, undo, hints, stars.
// Pure logic: no DOM access.

import { createBoard, findBlocker, removeArrow, restoreArrow, freeArrows, cloneBoard, distanceToEdge } from './board.js';

export const MAX_LIVES = 3;

export class GameSession {
  constructor(level, opts = {}) {
    this.level = level;
    this.maxLives = opts.maxLives || MAX_LIVES;
    this.reset();
  }

  reset() {
    this.board = createBoard(this.level);
    this.lives = this.maxLives;
    this.history = []; // ids of arrows removed by successful moves (for undo)
    this.mistakes = 0;
    this.hintsUsed = 0;
    this.moves = 0;
    this.undos = 0;
    this.status = 'playing'; // 'playing' | 'won' | 'lost'
  }

  get remaining() { return this.board.alive; }
  get total() { return this.board.arrows.length; }

  /**
   * Player taps arrow `id`.
   * Returns { type: 'escaped', id, distance, won } or
   *         { type: 'blocked', id, blocker, lives, lost } or { type: 'ignored' }
   */
  tap(id) {
    if (this.status !== 'playing') return { type: 'ignored' };
    const a = this.board.arrows[id];
    if (!a || !a.alive) return { type: 'ignored' };
    const blocker = findBlocker(this.board, id);
    if (blocker !== -1) {
      this.lives = Math.max(0, this.lives - 1);
      this.mistakes++;
      if (this.lives === 0) this.status = 'lost';
      return { type: 'blocked', id, blocker, lives: this.lives, lost: this.status === 'lost' };
    }
    const distance = distanceToEdge(this.board, id);
    removeArrow(this.board, id);
    this.history.push(id);
    this.moves++;
    if (this.board.alive === 0) this.status = 'won';
    return { type: 'escaped', id, distance, won: this.status === 'won' };
  }

  canUndo() { return this.status === 'playing' && this.history.length > 0; }

  /** Undo the last successful move. Lives are NOT refunded. Returns restored id or -1. */
  undo() {
    if (!this.canUndo()) return -1;
    const id = this.history.pop();
    restoreArrow(this.board, id);
    this.undos++;
    return id;
  }

  /**
   * Hint: id of one arrow that can escape right now (-1 if none).
   * Picks the free arrow whose removal frees the most other arrows.
   */
  hint({ count = true } = {}) {
    if (this.status !== 'playing') return -1;
    const free = freeArrows(this.board);
    if (!free.length) return -1;
    let best = free[0], bestGain = -1;
    const before = free.length;
    for (const id of free) {
      const b = cloneBoard(this.board);
      removeArrow(b, id);
      const gain = freeArrows(b).length - (before - 1);
      if (gain > bestGain) { bestGain = gain; best = id; }
    }
    if (count) this.hintsUsed++;
    return best;
  }

  /** 3 stars = no mistakes & no hints. -1 star per mistake. Using a hint caps at 2. Min 1 on a win. */
  stars() {
    if (this.status !== 'won') return 0;
    let s = 3 - this.mistakes;
    if (this.hintsUsed > 0) s = Math.min(s, 2);
    return Math.max(1, s);
  }
}
