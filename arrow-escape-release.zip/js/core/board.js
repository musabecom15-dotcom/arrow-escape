// Board model and move rules. Pure logic: no DOM access.
//
// RULES
// - The board is a grid of rows x cols cells. Each arrow sits in one cell and
//   points Up, Right, Down or Left.
// - Tapping an arrow sends it travelling in its direction. It escapes only if
//   EVERY cell between it and the board edge (in that direction) is empty.
// - If any arrow is in the way, the move is invalid ("blocked").

export const DIRS = ['U', 'R', 'D', 'L'];
export const DELTA = {
  U: { dr: -1, dc: 0 },
  R: { dr: 0, dc: 1 },
  D: { dr: 1, dc: 0 },
  L: { dr: 0, dc: -1 },
};

/**
 * Create a live board from level data.
 * level = { rows, cols, arrows: [[r, c, dirIndex], ...] }  (compact stored form)
 *      or { rows, cols, arrows: [{ r, c, d }, ...] }
 */
export function createBoard(level) {
  const { rows, cols } = level;
  const cells = new Array(rows * cols).fill(-1);
  const arrows = level.arrows.map((a, id) => {
    const arrow = Array.isArray(a)
      ? { id, r: a[0], c: a[1], d: DIRS[a[2]], alive: true }
      : { id, r: a.r, c: a.c, d: a.d, alive: true };
    if (arrow.r < 0 || arrow.r >= rows || arrow.c < 0 || arrow.c >= cols) {
      throw new Error(`Arrow ${id} out of bounds`);
    }
    if (!DELTA[arrow.d]) throw new Error(`Arrow ${id} has bad direction`);
    const idx = arrow.r * cols + arrow.c;
    if (cells[idx] !== -1) throw new Error(`Two arrows in cell ${arrow.r},${arrow.c}`);
    cells[idx] = id;
    return arrow;
  });
  return { rows, cols, cells, arrows, alive: arrows.length };
}

export function cloneBoard(b) {
  return {
    rows: b.rows,
    cols: b.cols,
    cells: b.cells.slice(),
    arrows: b.arrows.map((a) => ({ ...a })),
    alive: b.alive,
  };
}

/** Cell indices from the arrow's next cell to the edge (in travel order). */
export function rayCells(rows, cols, r, c, d) {
  const { dr, dc } = DELTA[d];
  const out = [];
  let rr = r + dr, cc = c + dc;
  while (rr >= 0 && rr < rows && cc >= 0 && cc < cols) {
    out.push(rr * cols + cc);
    rr += dr; cc += dc;
  }
  return out;
}

/** Id of the first arrow blocking this arrow's path, or -1 if the path is clear. */
export function findBlocker(board, id) {
  const a = board.arrows[id];
  const { dr, dc } = DELTA[a.d];
  let r = a.r + dr, c = a.c + dc;
  while (r >= 0 && r < board.rows && c >= 0 && c < board.cols) {
    const occ = board.cells[r * board.cols + c];
    if (occ !== -1) return occ;
    r += dr; c += dc;
  }
  return -1;
}

export function canEscape(board, id) {
  const a = board.arrows[id];
  return !!a && a.alive && findBlocker(board, id) === -1;
}

/** Number of cells the arrow travels before leaving the board. */
export function distanceToEdge(board, id) {
  const a = board.arrows[id];
  switch (a.d) {
    case 'U': return a.r + 1;
    case 'D': return board.rows - a.r;
    case 'L': return a.c + 1;
    default: return board.cols - a.c;
  }
}

export function removeArrow(board, id) {
  const a = board.arrows[id];
  if (!a.alive) throw new Error(`Arrow ${id} already removed`);
  a.alive = false;
  board.cells[a.r * board.cols + a.c] = -1;
  board.alive--;
}

export function restoreArrow(board, id) {
  const a = board.arrows[id];
  if (a.alive) throw new Error(`Arrow ${id} is already on the board`);
  const idx = a.r * board.cols + a.c;
  if (board.cells[idx] !== -1) throw new Error(`Cell for arrow ${id} is occupied`);
  a.alive = true;
  board.cells[idx] = id;
  board.alive++;
}

/** Ids of all arrows that can escape right now. */
export function freeArrows(board) {
  const out = [];
  for (const a of board.arrows) if (a.alive && findBlocker(board, a.id) === -1) out.push(a.id);
  return out;
}
