// Sound effects synthesised with the Web Audio API (no audio files needed).
// iOS requires audio to be "unlocked" by a user tap; we do that on first touch.

let ctx = null;
let master = null;
let enabled = true;

function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  try {
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.35;
    master.connect(ctx.destination);
  } catch {
    ctx = null;
  }
  return ctx;
}

export function unlockAudio() {
  const c = ensure();
  if (c && c.state === 'suspended') c.resume().catch(() => {});
}

export function setSoundEnabled(on) { enabled = !!on; }
export function isSoundEnabled() { return enabled; }

function tone({ freq = 440, to = null, dur = 0.12, type = 'sine', vol = 0.6, delay = 0 }) {
  if (!enabled || !ctx) return; // ctx is only created by unlockAudio() after a real tap
  const c = ctx;
  if (c.state !== 'running') { c.resume().catch(() => {}); return; }
  const t = c.currentTime + delay;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (to) osc.frequency.exponentialRampToValueAtTime(to, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(g); g.connect(master);
  osc.start(t); osc.stop(t + dur + 0.02);
}

export const sfx = {
  click() { tone({ freq: 660, dur: 0.05, type: 'triangle', vol: 0.3 }); },
  whoosh() { tone({ freq: 380, to: 1200, dur: 0.18, type: 'triangle', vol: 0.45 }); tone({ freq: 760, to: 1800, dur: 0.12, type: 'sine', vol: 0.15, delay: 0.03 }); },
  blocked() { tone({ freq: 180, to: 110, dur: 0.22, type: 'square', vol: 0.25 }); },
  undo() { tone({ freq: 900, to: 450, dur: 0.12, type: 'triangle', vol: 0.3 }); },
  hint() { tone({ freq: 880, dur: 0.08, type: 'sine', vol: 0.35 }); tone({ freq: 1320, dur: 0.1, type: 'sine', vol: 0.3, delay: 0.08 }); },
  star(i = 0) { tone({ freq: 784 * Math.pow(1.26, i), dur: 0.18, type: 'triangle', vol: 0.4 }); },
  win() { [523, 659, 784, 1047].forEach((f, i) => tone({ freq: f, dur: 0.22, type: 'triangle', vol: 0.4, delay: i * 0.09 })); },
  lose() { [392, 330, 262].forEach((f, i) => tone({ freq: f, dur: 0.25, type: 'sine', vol: 0.4, delay: i * 0.14 })); },
};
