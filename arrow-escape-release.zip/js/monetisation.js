// MONETISATION HOOKS (STUB) - intentionally does nothing in version 1.
//
// There are NO ad SDKs, NO payments and NO fake ads in this version.
// The rest of the game only talks to this file, so in the future you could
// plug in (for example) a rewarded-video provider or an in-app purchase store
// here without touching the gameplay code. Rules we commit to:
//   - Ads/purchases are always OPTIONAL and player-initiated. Never forced.
//   - The full game (all 100 levels) stays playable for free.

export const Monetisation = {
  /** Is an optional rewarded ad available right now? (v1: never) */
  isRewardedAvailable() { return false; },

  /**
   * Show an optional rewarded ad. Resolve true only if the player watched it.
   * Possible future uses: extra life after game over, bonus hint.
   */
  async showRewarded(/* placement: 'extra-life' | 'bonus-hint' */) { return false; },

  /** Cosmetic themes that could be unlocked later (purely visual). */
  listThemes() { return [{ id: 'default', name: 'Aurora', owned: true }]; },

  /** Hint packs that could be offered later. (v1: none) */
  listHintPacks() { return []; },

  async purchase(/* productId */) { return { ok: false, reason: 'not-available' }; },
};
