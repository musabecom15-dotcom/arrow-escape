// Registers the service worker for offline play. Fails silently and safely:
// e.g. inside itch.io's iframe or over plain http the game still works normally.

export function registerServiceWorker() {
  try {
    if (!('serviceWorker' in navigator)) return;
    const local = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    if (!window.isSecureContext && !local) return;
    const go = () => {
      navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {
        /* Not allowed here (iframe/sandbox/CDN) - that's fine, the game works online. */
      });
    };
    if (document.readyState === 'complete') go();
    else window.addEventListener('load', go, { once: true });
  } catch {
    /* ignore */
  }
}
