# Arrow Escape – Beginner Guide

Everything you need to run, test, publish and grow the game. No coding experience needed.
All tools mentioned are free.

---

## 1. How the game is built (plain English)

| Part | File(s) | What it does |
|---|---|---|
| The page | `index.html`, `css/style.css` | Holds every screen (splash, home, levels, settings, game) and how they look. |
| The brain | `js/core/*.js` | Pure game rules with no screen code: the board, which moves are allowed, the solver, the level generator, lives/undo/hints/stars. Because it has no screen code, Node can test it automatically. |
| The levels | `js/data/levels.js` | 100 levels, generated once from fixed "seeds" (numbers) so they never change. |
| The face | `js/app.js`, `js/ui/*.js` | Draws the board, animations, particles, menus, and turns taps into moves. |
| Memory | `js/storage.js` | Saves stars, unlocked levels and settings on the phone (localStorage). |
| Sound | `js/audio.js` | Makes the sound effects with code (no audio files). |
| Offline | `sw.js`, `manifest.webmanifest`, `js/pwa.js`, `icons/` | Lets the game install to the home screen and work with no internet. |
| Future money | `js/monetisation.js` | Empty "hooks" only. No ads, no payments in v1. |

**How every level is guaranteed solvable.** The generator starts with an empty board and adds arrows one at
a time. An arrow is only placed if *its own* path to the edge is clear at that moment. Arrows added later may
block it, but those get removed first when you play backwards. So "remove in reverse order" always works.
A solver then double-checks every level, and the automated test checks all 100 again.

**How difficulty grows.** Boards grow from 3×3 to 10×8, get fuller (about 60% → 90% of cells), and the
generator favours spots that block other arrows, creating longer chains (the "layers" number in
`tools/build-levels.js` output goes from 1 at level 1 to about 18 at level 100).

---

## 2. Run the game on your computer

You need a tiny local web server (double-clicking `index.html` will show a blank page because browsers block
modules on `file://`). Pick ONE option:

**Option A – VS Code + Live Server (easiest)**
1. Install Visual Studio Code from https://code.visualstudio.com (free).
2. Open VS Code → Extensions (squares icon on the left) → search **Live Server** (by Ritwick Dey) → Install.
3. File → Open Folder… → choose the unzipped `arrow-escape` folder.
4. Right-click `index.html` → **Open with Live Server**. Your browser opens the game.

**Option B – Python (already on Mac/Linux; Windows: install from python.org, tick "Add to PATH")**
1. Open a terminal (Mac: Terminal app; Windows: Command Prompt) in the game folder.
   (Windows tip: open the folder in File Explorer, click the address bar, type `cmd`, press Enter.)
2. Run `python3 -m http.server 8000` (Windows: `py -m http.server 8000`).
3. Open http://localhost:8000 in Chrome. Press Ctrl+C in the terminal to stop.

**Test on your phone (same Wi-Fi):** with Option B running, find your computer's local IP
(Windows: `ipconfig`; Mac: System Settings → Wi-Fi → Details) and open `http://YOUR-IP:8000` on the phone.
(Offline/installation needs https, so test those after publishing to GitHub Pages.)

**Phone preview on a computer:** in Chrome press F12 → click the phone/tablet icon → pick "iPhone 12 Pro".

---

## 3. Run the automated tests

1. Install **Node.js LTS** from https://nodejs.org (free, click the big LTS button, install with defaults).
2. Open a terminal in the game folder and run:

```
node tests/run-tests.js
```

You should see 32 green ticks and `32 passed, 0 failed`. They check: move rules, blocked moves cost lives,
game over after 3 mistakes, undo (last-in-first-out, no life refund), hints are always valid moves, star rules,
restart, the generator gives identical boards for the same seed, 500 random boards are all solvable, the daily
puzzle is the same for the same date, **all 100 levels are solvable**, stored levels match their seeds,
difficulty rises chapter by chapter, and every board fits a phone.

3. Release audit (checks every file is present and paths are correct for hosting):

```
node tools/check-release.js
```

Optional tools (only if you change things): `node tools/build-levels.js` regenerates the 100 levels;
`node tools/make-icons.js` redraws the icons. After either, run the tests again.

---

## 4. Test every feature by hand

| Feature | How to test | Expected |
|---|---|---|
| Splash | Load the page | Logo animates; goes to Home after ~1.5 s or a tap. |
| Play / Continue | Tap Play | Opens the highest unlocked level. After beating level 1 the button says "Continue · Level 2". |
| Tutorials | Open levels 1–10 | A tip card appears above the board; "Got it" hides it. Level 1 also glows one safe arrow. |
| Escape move | Tap an arrow with nothing in front of it | It slides off the board with a whoosh and a particle burst; "arrows left" drops; progress bar fills. |
| Blocked move | Tap an arrow pointing at another arrow | It nudges and shakes, the blocker flashes red, a heart breaks, a message appears, phone vibrates (Android). |
| Game over | Make 3 blocked taps | "Out of lives" screen with Try again / Levels. |
| Restart | Tap Restart mid-level | Board resets, 3 hearts. |
| Undo | Clear an arrow, tap Undo | The arrow pops back. Hearts are not refunded. Undo is greyed out when there's nothing to undo. |
| Hint | Tap Hint | One arrow glows yellow; tapping it always works. A message says you're capped at 2 stars. |
| Stars | Win with 0 mistakes & no hint / 1 mistake / using hint / 2 mistakes | 3 / 2 / 2 / 1 stars. |
| Unlocking | Beat a level, open Levels | Next level unlocked (purple glow); stars shown under the number. Locked levels show a padlock. |
| Saving | Beat a level, close the tab, reopen | Stars and unlocks are still there. |
| Daily Challenge | Home → Daily Challenge | Board titled with today's date. Same board on any device today; different tomorrow. Winning marks "Done ★★★" on Home. |
| Sound | Settings → Sound off/on | Effects stop/start. (iPhone: also check the silent switch is off.) |
| Dark mode | Settings → Dark mode | Whole game switches to dark colours. |
| Colourblind | Settings → Colourblind symbols | Safer colours plus a small shape per direction (▲ up, ■ right, ● down, ◆ left). See the "Arrow key" card. |
| Reduce motion | Settings → Reduce motion | Animations become near-instant; fewer particles. |
| Reset progress | Settings → Reset progress → Reset | Stars cleared, only level 1 unlocked; settings kept. Cancel does nothing. |
| Back button | Android back gesture | Goes back a screen instead of closing the game. |
| Offline (after publishing) | Open the GitHub Pages site once, turn on Airplane mode, reopen | Game loads and every level plays. |

---

## 5. Publish free on GitHub Pages (no command line)

1. Create a free account at https://github.com.
2. Top-right **+** → **New repository**. Name: `arrow-escape`. Choose **Public**. Click **Create repository**.
3. On the new empty repo page, click the link **uploading an existing file**.
4. Unzip `arrow-escape-release.zip` on your computer. Open the unzipped folder, select **everything inside it**
   (`index.html`, `css`, `js`, `icons`, `docs`, `tests`, `tools`, `manifest.webmanifest`, `sw.js`, …) and drag it
   into the browser upload box. Use Chrome or Edge so sub-folders upload correctly.
   *Important:* `index.html` must end up at the top level of the repository, not inside another folder.
5. Scroll down, click **Commit changes**. Check the file list shows `index.html` at the top level.
6. `.nojekyll` is a hidden file and may not upload by drag-and-drop. That's okay (it's only a safety extra).
   To add it: **Add file → Create new file**, name it `.nojekyll`, leave it empty, **Commit changes**.
7. Go to **Settings** (repo tab) → **Pages** (left menu). Under "Build and deployment": Source = **Deploy from a
   branch**, Branch = **main**, folder = **/ (root)** → **Save**.
8. Wait 1–3 minutes, refresh the Pages settings page. Your link appears:
   `https://YOUR-USERNAME.github.io/arrow-escape/`. Open it on your phone.

**Updating later:** edit/upload the changed files the same way (uploading a file with the same name replaces it).
Then open `sw.js` on GitHub (pencil icon), change `const CACHE_VERSION = 'v1.0.0';` to `'v1.0.1'` and commit,
so phones fetch the new version. Players may need to close and reopen the game once.

---

## 6. Publish free on itch.io

1. Create a free account at https://itch.io → top-right menu → **Upload new project**.
2. Title: *Arrow Escape: 100 Levels*. **Kind of project: HTML**. Classification: Games. Pricing: "No payments"
   (or "Donate" if you'd like optional tips).
3. **Uploads → Upload files** → choose `arrow-escape-release.zip` (it has `index.html` at the top, as itch.io requires).
   Tick **This file will be played in the browser**.
4. **Embed options:**
   - Viewport dimensions: **405 × 720** (portrait; 360 × 640 also works).
   - Tick **Mobile friendly**, Orientation **Portrait**.
   - Tick **Fullscreen button**.
   - Leave "Automatically start on page load" off (players click "Run game"; this also helps sound start on iPhone).
5. Add a short description, a cover image (use a screenshot) and tags (puzzle, casual, mobile, minimalist).
6. Save with **Visibility: Draft**, click **View page**, play it on your computer and phone, then set it to **Public**.

Notes for itch.io: the game runs inside an iframe on a different domain, so the offline/install feature does
not apply there (the game simply works online, by design). Progress saves in the browser; if a browser blocks
storage in iframes, Settings shows a note that progress lasts only for the session.

---

## 7. Add to home screen

**iPhone / iPad (Safari):**
1. Open your GitHub Pages link in **Safari** (not Chrome on iPhone for this step).
2. Tap the **Share** button (square with an up arrow).
3. Scroll and tap **Add to Home Screen** → **Add**.
4. Launch from the new icon. It opens full-screen. Open it once online so it caches; after that it works offline.

**Android (Chrome):**
1. Open your GitHub Pages link in **Chrome**.
2. Tap **⋮** (top-right) → **Add to Home screen** or **Install app** → **Install**.
3. Launch from the icon. Works offline after the first visit.

---

## 8. Pre-release testing checklist

- [ ] `node tests/run-tests.js` shows 0 failed.
- [ ] `node tools/check-release.js` passes.
- [ ] Chrome desktop: F12 → Console shows no red errors while playing.
- [ ] Tested on a real iPhone (Safari) and a real Android phone (Chrome).
- [ ] Small phone (e.g. iPhone SE size in DevTools) and large phone: nothing cut off; Level 100 board fits.
- [ ] Rotating the phone doesn't break the layout.
- [ ] Every row of the table in section 4 passes.
- [ ] Levels 1, 10, 11, 50, 100 completed at least once.
- [ ] Progress survives closing and reopening the browser.
- [ ] Installed to home screen on iPhone and Android; icon looks right.
- [ ] Airplane mode: installed app still opens and plays.
- [ ] After an update: `CACHE_VERSION` in `sw.js` was bumped, and the phone shows the new version after reopening.
- [ ] Dark mode, colourblind and reduce motion all readable.
- [ ] Sound off really mutes; iPhone silent switch respected.
- [ ] itch.io draft page: game runs, fullscreen button works, mobile layout OK.
- [ ] Wording/spelling checked; your name in `LICENSE`.

---

## 9. Monetisation & improvement roadmap

Principles: the whole game stays free; any ad or purchase is **optional and player-chosen**; never forced.

**Ready-made hooks (in `js/monetisation.js`):** `isRewardedAvailable()`, `showRewarded(placement)`,
`listThemes()`, `listHintPacks()`, `purchase(id)`. The game already asks `isRewardedAvailable()` on the game-over
screen and would show a "Watch a video for +1 life" button if it ever returned true. Storage already has
`wallet.bonusHints` and `cosmetics` fields reserved.

**Possible steps (in order of effort):**
1. *Donations*: itch.io "Donate" pricing or a Ko-fi link in Settings. Zero code risk.
2. *Cosmetic themes*: extra colour palettes (CSS variables in `style.css`) unlocked by stars first, later purchasable.
3. *Rewarded ads on the web*: options include Google's H5 Games Ads (requires approval) or publishing on web
   portals with their own SDKs (e.g. CrazyGames, Poki, GameDistribution) that share revenue.
   In the UK/EU you'd need a consent banner and a privacy policy before showing personalised ads.
4. *App stores*: wrap the same code with Capacitor (free) for Google Play (one-off developer fee, about $25) and the
   Apple App Store (yearly fee, about $99, and a Mac is needed to build). Then hint packs/themes via in-app purchases.

**Game improvements:**
- New mechanics for later chapters: walls/rocks, long multi-cell arrows, arrows that turn, ice tiles, timed levels.
- More level packs (the generator can make unlimited levels: add seeds/bands in `progression.js`).
- Daily streaks and a calendar of past dailies; share-your-result text.
- Achievements and a stats screen (data is already counted in `stats`).
- Background music toggle (generated in code), more sound variety.
- Localisation (all text is in `index.html`, `tutorials.js` and `app.js`).
- Optional cloud save/leaderboards later (would need a free backend tier such as Firebase/Supabase).
